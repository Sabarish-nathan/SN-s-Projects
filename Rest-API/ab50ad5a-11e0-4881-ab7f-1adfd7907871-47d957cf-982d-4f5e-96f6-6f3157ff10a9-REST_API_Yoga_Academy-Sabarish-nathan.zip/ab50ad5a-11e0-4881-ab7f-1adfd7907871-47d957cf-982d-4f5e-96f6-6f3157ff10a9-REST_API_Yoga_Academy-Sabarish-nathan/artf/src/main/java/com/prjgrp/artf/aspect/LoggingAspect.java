package com.prjgrp.artf.aspect;

public class LoggingAspect {

}
