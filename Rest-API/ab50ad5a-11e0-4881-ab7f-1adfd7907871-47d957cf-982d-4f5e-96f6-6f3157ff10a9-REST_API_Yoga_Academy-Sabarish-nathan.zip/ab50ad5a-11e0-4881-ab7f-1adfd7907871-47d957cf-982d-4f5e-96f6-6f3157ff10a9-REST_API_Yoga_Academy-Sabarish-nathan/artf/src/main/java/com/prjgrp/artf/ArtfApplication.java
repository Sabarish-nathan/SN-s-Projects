package com.prjgrp.artf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtfApplication.class, args);
	}

}
